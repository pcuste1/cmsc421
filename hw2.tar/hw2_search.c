#include <stdio.h>
#define NUM_ENTS 16
int data[NUM_ENTS] = {15, 11, 3, 9, 12, 0, 1, 5, 10, 14, 2, 6, 4, 8, 13, 7};
main(int argc, char **argv)
{
/* YOUR CODE HERE TO SEARCH data[]for number specified in argv[1]*/
/* Recursion highly recommended! */

  if( argc == 2)
    {
      if( fork() == 0 )
	{
	  printf("The argument supplied is %s\n", argv[1]);
	  search(0, NUM_ENTS, atoi(argv[1]));
	}
      while(wait(NULL) > 0) {}
    }
}

int search(int p, int q, int x)
{
  if( q - p > 1)
    { 
      int m = (int) (q + p)/2;
      //printf("Looking for %d between [%d , %d] half at %d\n", x, p, q, m);
      int b;
      b = fork();
      if(b == 0)
	{
	  search(p, m, x);
	} 
      else
	{ 
	  search(m, q, x);
	}
    }
  else
    {
      if( data[p] == x ) 
	{
	  printf("Found %d in position %d\n", x, p);
	}
    }
  return 0;
}
